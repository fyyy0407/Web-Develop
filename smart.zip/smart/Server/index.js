//index.js
const userApi = require('./Api/userApi')
const menuApi = require('./Api/menuApi')
const fs = require('fs')              // provides a lot of functionality to access and interact with the file system.
const path = require('path')          //provides utilities for working with file and directory paths.
const bodyParser = require('body-parser') //imports the body-parser middleware necessary for parsing the body of incoming requests; 
const express = require('express')
const app = express()

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
  extended: false
}))

// 后端api路由
app.use('/api/user', userApi)
app.use('/api/menu', menuApi)

// 监听端口
app.listen(3000);         //starts the server and listens for connections on port 3000.
console.log('success listen at port:3000......')
