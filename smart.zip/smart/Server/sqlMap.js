// sqlMap.js
var sqlMap = {
  recipes: {
    add: 'insert into recipes(title, description, imageURL, totalTime) values (?, ?, ?, ?)',
    delete: 'delete from recipes where recipeID = ?',
    search: 'select * from recipes where title = ?' //根据菜名查找菜谱
  },
  ingredients: {
    add: 'insert into ingredients(name, imageURL) values (?, ?)',
    search: 'select * from ingredients where name = ?', //查找食材信息
    listByRecipe: 'select * from RecipeIngredients where RecipeID = ?' //列出某道菜的所有食材
  },
  instructions: {
    add: 'insert into instructions(RecipeID, StepNumber, Description, Action, Duration, Temperature, Speed) values (?, ?, ?, ?, ?, ?, ?)',
    search: 'select * from instructions where RecipeID = ?', //根据菜名查找其所有炒菜步骤
  }
}

module.exports = sqlMap;

  