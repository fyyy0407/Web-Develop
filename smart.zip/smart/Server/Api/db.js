//db.js
const mysql = require('mysql');

const connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'fyyy0407',
    password: 'Fy040723',
    database: 'menu',
    port: '3306' //mysql连接端口
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to database');
});

module.exports = connection;

// 在其他模块中导入：
// const db = require('./db');
// const sqlMap = require('./sqlMap');

// // 示例：添加一个读者
// let name = 'John Doe';
// db.query(sqlMap.reader.add, [name], function (error, results, fields) {
//     if (error) throw error;
//     console.log('Reader added successfully!');
// });

// 关闭链接：connection.end()


// module.exports = {
//     mysql: {
//         host: '127.0.0.1', //mysql连接ip地址
//         user: 'fyyy0407',
//         password: 'Fy040723', //mySql用户名密码
//         database: 'menu',
//         port: '3306' //mysql连接端口
//     }
// }
