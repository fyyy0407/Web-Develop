//menuApi.js
var models = require('db.js')
var express = require('express')
var router = express.Router()
var mysql = require('mysql')
var $sql = require('./sqlMap')

// 连接数据库
var conn = mysql.createConnection(models.mysql)
conn.connect()
var jsonWrite = function (res, ret) {
  if (typeof ret === 'undefined') {
    res.json({
      code: '1',
      msg: '操作失败'
    })
  } else {
    res.json(ret)
  }
}

// GET route for listing menu items
router.get('/items', async (req, res) => {
  try {
    const [rows, fields] = await promisePool.query('SELECT * FROM MenuItems');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST route for adding a new menu item
router.post('/items', async (req, res) => {
  try {
    const { name, price } = req.body;
    const [result] = await promisePool.execute('INSERT INTO MenuItems (name, price) VALUES (?, ?)', [name, price]);
    const newItem = { id: result.insertId, name, price };
    res.status(201).json(newItem);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE route for deleting a menu item
router.delete('/items/:id', async (req, res) => {
  try {
    const itemId = parseInt(req.params.id);
    await promisePool.execute('DELETE FROM MenuItems WHERE id = ?', [itemId]);
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
